package com.ruoyi.cms.comment.controller;

import java.util.List;
import java.util.Set;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.cms.comment.domain.CmsCommentLike;
import com.ruoyi.common.core.utils.poi.ExcelUtil;
import com.ruoyi.common.core.web.page.TableDataInfo;
import com.ruoyi.common.log.annotation.Log;
import com.ruoyi.common.log.enums.BusinessType;
import com.ruoyi.common.security.annotation.RequiresPermissions;
import com.ruoyi.common.security.auth.AuthUtil;
import com.ruoyi.common.security.utils.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.core.web.controller.BaseController;
import com.ruoyi.common.core.web.domain.AjaxResult;
import com.ruoyi.cms.comment.domain.CmsComment;
import com.ruoyi.cms.comment.service.ICmsCommentService;

/**
 * 评论管理Controller
 * 
 * @author ning
 * @date 2022-01-21
 */
@RestController
@RequestMapping("/cms/comment")
public class CmsCommentController extends BaseController
{
    @Autowired
    private ICmsCommentService cmsCommentService;

    /**
     * 首页查询评论列表
     */
    @GetMapping("/cms/list")
    public TableDataInfo cmsList(CmsComment cmsComment)
    {
        startPage();
        List<CmsComment> list = cmsCommentService.selectCommentList(cmsComment);
        return getDataTable(list);
    }

    /**
     * 首页新增评论
     */
    @PostMapping("/cms/addComment")
    public AjaxResult addComment(@RequestBody CmsComment cmsComment)
    {
        Long parentId = cmsComment.getParentId();
        if (parentId!=null){
            CmsComment comment = cmsCommentService.selectCmsCommentById(parentId);
            if (comment.getMainId()!=null){
                cmsComment.setMainId(comment.getMainId());
            }else {
                cmsComment.setMainId(parentId);
            }
        }
        return toAjax(cmsCommentService.insertCmsComment(cmsComment));
    }

    /**
     * 首页新增点赞
     */
    @PostMapping("/cms/addCmsCommentLike")
    public AjaxResult addCmsCommentLike(@RequestBody CmsCommentLike cmsCommentLike)
    {
        return toAjax(cmsCommentService.addCmsCommentLike(cmsCommentLike));
    }

    /**
     * 首页删除点赞
     */
    @Log(title = "删除评论点赞", businessType = BusinessType.DELETE)
    @PostMapping("/cms/delCmsCommentLike")
    public AjaxResult delCmsCommentLike(@RequestBody CmsCommentLike cmsCommentLike)
    {
        return toAjax(cmsCommentService.delCmsCommentLike(cmsCommentLike));
    }

    /**
     * 查询评论管理列表
     */
    @RequiresPermissions("cms:comment:list")
    @GetMapping("/list")
    public TableDataInfo list(CmsComment cmsComment)
    {

        // 角色集合
        Set<String> roles = AuthUtil.authLogic.getRoleList();
        if (!SecurityUtils.isAdmin(SecurityUtils.getUserId())&&!roles.contains("admin")&&!roles.contains("cms")){
            cmsComment.setCreateBy(SecurityUtils.getUsername());
        }
        cmsComment.setDelFlag("0");
        startPage();
        List<CmsComment> list = cmsCommentService.selectCmsCommentList(cmsComment);
        return getDataTable(list);
    }

    /**
     * 导出评论管理列表
     */
    @RequiresPermissions("cms:comment:export")
    @Log(title = "评论管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, CmsComment cmsComment)
    {
        List<CmsComment> list = cmsCommentService.selectCmsCommentList(cmsComment);
        ExcelUtil<CmsComment> util = new ExcelUtil<CmsComment>(CmsComment.class);
        util.exportExcel(response, list, "评论管理数据");
    }

    /**
     * 获取评论管理详细信息
     */
    @RequiresPermissions("cms:comment:query")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return AjaxResult.success(cmsCommentService.selectCmsCommentById(id));
    }

    /**
     * 新增评论管理
     */
    @RequiresPermissions("cms:comment:add")
    @Log(title = "评论管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsComment cmsComment)
    {
        return toAjax(cmsCommentService.insertCmsComment(cmsComment));
    }

    /**
     * 修改评论管理
     */
    @RequiresPermissions("cms:comment:edit")
    @Log(title = "评论管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsComment cmsComment)
    {
        return toAjax(cmsCommentService.updateCmsComment(cmsComment));
    }

    /**
     * 删除评论管理
     */
    @RequiresPermissions("cms:comment:remove")
    @Log(title = "评论管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(cmsCommentService.deleteCmsCommentByIds(ids));
    }
}
