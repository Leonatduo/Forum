package com.ruoyi.cms;

import com.ruoyi.common.security.annotation.EnableCustomConfig;
import com.ruoyi.common.security.annotation.EnableRyFeignClients;
import com.ruoyi.common.swagger.annotation.EnableCustomSwagger2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * 博客模块
 * 
 * @author ruoyi
 */
@EnableCustomConfig
@EnableCustomSwagger2
@EnableRyFeignClients
@SpringBootApplication
public class RuoYiBlogApplication
{
    private static final Logger log = LoggerFactory.getLogger(RuoYiBlogApplication.class);
    public static void main(String[] args) throws UnknownHostException {
        ConfigurableApplicationContext application =  SpringApplication.run(RuoYiBlogApplication.class, args);
        System.out.println("(♥◠‿◠)ﾉﾞ  博客模块启动成功   ლ(´ڡ`ლ)ﾞ  \n" +
                " .-------.       ____     __        \n" +
                " |  _ _   \\      \\   \\   /  /    \n" +
                " | ( ' )  |       \\  _. /  '       \n" +
                " |(_ o _) /        _( )_ .'         \n" +
                " | (_,_).' __  ___(_ o _)'          \n" +
                " |  |\\ \\  |  ||   |(_,_)'         \n" +
                " |  | \\ `'   /|   `-'  /           \n" +
                " |  |  \\    /  \\      /           \n" +
                " ''-'   `'-'    `-..-'              ");

        Environment env = application.getEnvironment();
        String appName = env.getProperty("app.name");
        String ip = InetAddress.getLocalHost().getHostAddress();
        String serverPort = env.getProperty("server.port");
        String contextPath = env.getProperty("server.servlet.context-path") != null ? env.getProperty("server.servlet.context-path") : "";
        // 启动Log
        log.info("\n----------------------------------------------------------\n" +
                "Application " + appName + " is running! Access URLs:\n" +
                "Local: \t\t\t\thttp://localhost:" + serverPort + contextPath + "\n" +
                "External: \t\t\thttp://" + ip + ":" + serverPort + contextPath + "\n" +
                "Druid-Monitor: \t\thttp://" + ip + ":" + serverPort + contextPath + "druid\n" +
                "Swagger Api: \t\thttp://" + ip + ":" + serverPort + contextPath + "v3/api-docs\n" +
                "Knife4j Document: \thttp://" + ip + ":" + serverPort + contextPath + "doc.html\n" +
                "----------------------------------------------------------\n");
    }
}
